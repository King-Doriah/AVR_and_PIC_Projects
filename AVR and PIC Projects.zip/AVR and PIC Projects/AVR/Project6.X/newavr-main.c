#include <avr/io.h>
#define F_CPU 8000000UL
#include <util/delay.h>

int main(void){
    DDRB = 0x7F;
    DDRC = 0x01;
    PORTC |= (1<<PC2) | (1<<PC0) | (1<<PC3);
    char display[]={0X3F, 0X06, 0X5B, 0X4F, 0x66, 0X6D, 0X7D, 0X07, 0X7F, 0X67};
    int count = 0;
    PORTB = display[0];
    while(1){
        if(count > 9 || count <= 0){
            count = 0;
            PORTB = display[count];
        }
        if(!(PINC & (1<<PC2))){
            _delay_ms(50);
            count++;
            PORTB = display[count];
        }else if(!(PINC & (1<<PC3))){
            _delay_ms(50);
            count--;
            PORTB = display[count];
        }
    }
}