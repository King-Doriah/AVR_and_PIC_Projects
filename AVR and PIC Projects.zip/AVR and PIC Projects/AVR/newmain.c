/*
 * File:   newmain.c
 * Author: MIRALDINO PAULO
 *
 * Created on July 27, 2012, 2:26 AM
 */


#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void) {
    DDRD = 0x00;
    while(1){
        PORTD |= (1<<PD6);
        _delay_ms(500);
        PORTD &= ~(1<<PD6);
        _delay_ms(500);
    }
    return;
}
