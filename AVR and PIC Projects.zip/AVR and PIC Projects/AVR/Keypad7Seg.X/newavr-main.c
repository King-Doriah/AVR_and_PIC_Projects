#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

char key_read(void);

int main(void) {
    char key;
    char display[]={0X3F, 0X06, 0X5B, 0X4F, 0x66, 0X6D, 0X7D, 0X07, 0X7F, 0X67};
    DDRD = 0x0F;
    PORTD = 0x70;
    
    DDRB = 0xFF;
    PORTB = 0x00;
    
    while (1) {
        key = key_read();
        _delay_ms(60);
        if(key != 'n'){
            if(key == '0'){ PORTB = display[0]; }
            if(key == '1'){ PORTB = display[1]; }
            if(key == '2'){ PORTB = display[2]; }
            if(key == '3'){ PORTB = display[3]; }
            if(key == '4'){ PORTB = display[4]; }
            if(key == '5'){ PORTB = display[5]; }
            if(key == '6'){ PORTB = display[6]; }
            if(key == '7'){ PORTB = display[7]; }
            if(key == '8'){ PORTB = display[8]; }            
            if(key == '9'){ PORTB = display[9]; }
        }
    }
}

char key_read(void){
    char key = 'n';
    PORTD = 0x0F;

    PORTD &= ~(1<<PD0);
    if(!(PIND & (1<<PD4))){ _delay_ms(50); while(!(PIND & (1<<PD4))); return '1'; }
    if(!(PIND & (1<<PD5))){ _delay_ms(50); while(!(PIND & (1<<PD5))); return '2'; }
    if(!(PIND & (1<<PD6))){ _delay_ms(50); while(!(PIND & (1<<PD6))); return '3'; }

    PORTD = 0x0F;
    PORTD &= ~(1<<PD1);
    if(!(PIND & (1<<PD4))){ _delay_ms(50); while(!(PIND & (1<<PD4))); return '4'; }
    if(!(PIND & (1<<PD5))){ _delay_ms(50); while(!(PIND & (1<<PD5))); return '5'; }
    if(!(PIND & (1<<PD6))){ _delay_ms(50); while(!(PIND & (1<<PD6))); return '6'; }    

    PORTD = 0x0F;
    PORTD &= ~(1<<PD2);
    if(!(PIND & (1<<PD4))){ _delay_ms(50); while(!(PIND & (1<<PD4))); return '7'; }
    if(!(PIND & (1<<PD5))){ _delay_ms(50); while(!(PIND & (1<<PD5))); return '8'; }
    if(!(PIND & (1<<PD6))){ _delay_ms(50); while(!(PIND & (1<<PD6))); return '9'; }    

    PORTD = 0x0F;
    PORTD &= ~(1<<PD3);
    if(!(PIND & (1<<PD4))){ _delay_ms(50); while(!(PIND & (1<<PD4))); return '*'; }
    if(!(PIND & (1<<PD5))){ _delay_ms(50); while(!(PIND & (1<<PD5))); return '0'; }
    if(!(PIND & (1<<PD6))){ _delay_ms(50); while(!(PIND & (1<<PD6))); return '#'; }    

    return key;
}