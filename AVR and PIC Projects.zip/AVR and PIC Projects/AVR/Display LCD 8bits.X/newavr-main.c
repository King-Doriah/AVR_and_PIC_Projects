#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

void lcdCmd(char cmd){
    PORTD = cmd;
    PORTC &= ~(1<<PC2);
    PORTC |= (1<<PC3);
    _delay_ms(2);
    PORTC &= ~(1<<PC3);
    _delay_ms(2);
}

void lcdData(char data){
    PORTD = data;
    PORTC |= (1<<PC2);
    PORTC |= (1<<PC3);
    _delay_ms(2);
    PORTC &= ~(1<<PC3);
    _delay_ms(2);
}

void lcdString(char str[]){
    unsigned int i = 0;
    while(str[i] != '\0'){
        lcdData(str[i]);
        i++;
    }
}

void lcdInit(void){
    DDRD = 0xFF;
    DDRC |= (1<<PC2) | (1<<PC3);

    lcdCmd(0x38);
    lcdCmd(0x06);
    lcdCmd(0x0C); //0x0F => Habilita o Cursor
    lcdCmd(0x03);
    lcdCmd(0x01);
    lcdCmd(0x80);    
}

int main(void){
    lcdInit();
    char str[]="Miraldino Paulo";
    lcdString(str);
    while(1);
}