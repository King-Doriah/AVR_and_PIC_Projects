/*
 * File:   newavr-main.c
 * Author: MIRALDINO PAULO
 *
 * Created on 16 de Agosto de 2023, 18:36
 */

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd.h" //Driver de LCD
#include "adc.h" //Driver de ADC

int main(void) {
    /* Replace with your application code */
    lcdInit();
    Init_ADC();
    
    char adc_str[10];
    uint16_t adc;
    float temp;
    
    while (1) {
        adc = Read_ADC(0);
       
        temp = (adc*4.88)/10.00;
        
        sprintf(adc_str, "%d%cC", (int)temp, 0xdf);
        lcdString(adc_str);
        _delay_ms(50);
        lcdClear();
    }
}
