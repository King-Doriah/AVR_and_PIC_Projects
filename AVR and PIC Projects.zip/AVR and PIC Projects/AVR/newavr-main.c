/*
 * File:   newavr-main.c
 * Author: MIRALDINO PAULO
 *
 * Created on July 27, 2012, 2:37 AM
 */

#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "USART/HAL_USART.h"

int main(void)
{
	USART_Begin();
	int message=23333;
	while(1)
	{
		USART_Print(message);
		USART_SendLine();
		_delay_ms(500);
	}
}


/*
int main(void) {
    DDRD |= (1<<PD6);
    while (1) {
        PORTD |= (1<<PD6);
        _delay_ms(500);
        PORTD &= ~(1<<PD6);
        _delay_ms(500);
    }
}*/
