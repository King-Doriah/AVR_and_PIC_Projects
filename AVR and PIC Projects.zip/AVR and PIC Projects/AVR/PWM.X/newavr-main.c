#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

// Defini��es de macros para melhor legibilidade
#define PWM_PIN   PB1     // Pino 9 (OC1A)
#define ADC_PIN   PC0     // Pino 23 (ADC0)

void setup_pwm() {
    // Configura o Timer1 para gerar PWM no pino OC1A (PB1)
    TCCR1A |= (1 << COM1A1) | (1 << WGM11) | (1 << WGM10);
    TCCR1B |= (1 << WGM13) | (1 << WGM12) | (1 << CS11); // Prescaler 8

    // Define o pino OC1A (PB1) como sa�da
    DDRB |= (1 << PB1);
}

void setup_adc() {
    // Configura o ADC
    ADMUX |= (1 << REFS0);      // Tens�o de refer�ncia como AVCC
    ADMUX |= (1 << ADLAR);      // Alinhamento � esquerda do resultado
    ADCSRA |= (1 << ADEN);      // Habilita o ADC
}

uint16_t read_adc() {
    // Inicia uma convers�o ADC no pino ADC0 (PC0)
    ADMUX &= 0xF8;              // Limpa os bits de sele��o do canal
    ADMUX |= (1 << MUX0);       // Seleciona o canal ADC0
    ADCSRA |= (1 << ADSC);      // Inicia a convers�o

    // Aguarda at� a convers�o ser conclu�da
    while (ADCSRA & (1 << ADSC));

    return ADC;                 // Retorna o valor convertido
}

int main() {
    setup_pwm();
    setup_adc();

    while (1) {
        // L� o valor do ADC
        uint16_t adc_value = read_adc();

        // Define o valor do PWM com base no valor lido do ADC
        OCR1A = adc_value;

        _delay_ms(100);  // Aguarda um curto per�odo de tempo
    }

    return 0;
}