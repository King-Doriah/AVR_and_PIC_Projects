#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

ISR(PCINT1_vect);

int main(void){
    
    DDRD = 0xFF;
    PORTD = 0x00;
    
    DDRC = 0x00;
    PORTC |= (1<<PC2) | (1<<PC3);
    
    PCICR |= (1<<PCIE1);
    PCMSK1 |= (1<<PCINT10) | (1<<PCINT11);
    sei();
    
    while(1){
        PORTD ^= (1<<PD5);
        _delay_ms(500);
    }
    return 0;
}

ISR(PCINT1_vect){
    if(!(PINC & (1<<PC2))){
        PORTD |= (1<<PD3);
    }else if(!(PINC & (1<<PC3))){
        PORTD &= ~(1<<PD3);
    }
}
