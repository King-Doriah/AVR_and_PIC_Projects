#include <avr/io.h>
#define BAUD_RATE 9600
#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

ISR(USART_RX_vect){
    char data = 0;
    data = UDR0;
    UDR0 = data;
}

int main(void) {
    UBRR0 = 103;
    UCSR0B = 0b10011000;
    UCSR0C = 0b00000110;
    sei();
    
    while(1){
        
    }
    return 0;
}