/*
 * File:   newavr-main.c
 * Author: MIRALDINO PAULO
 *
 * Created on 16 de Agosto de 2023, 19:07
 */

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd.h"

#define Trigger PB5
#define Echo    PB6

void setup(void){
    DDRB |= (1<<PB5);
    DDRB &= ~(1<<PB6);
    
    TCCR1B |= (1<<CS10);
}

uint16_t readDistance(void){
    uint16_t duration;
    uint16_t distance;
    PORTB |= (1<<Trigger);
    _delay_us(10);
    PORTB &= ~(1<<Trigger);

    while(!(PINB & (1<<Echo)));
    
    TCNT1 = 0;
    
    while((PINB & (1<<Echo)));
    
    duration = TCNT1;
    
    distance = duration/58.8;
    
    return distance;
}

int main(void) {
    setup();
    lcdInit();
    uint16_t distance;
    char readDst[10];
    while (1) {
        distance = readDistance();
        sprintf(readDst, "%d", distance);
        lcdString(readDst);
        _delay_ms(50);
        lcdClear();
    }
}
