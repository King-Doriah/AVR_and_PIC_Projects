
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
#include <xc.h>
#include <stdio.h>
#include "lcd.h"
#define _XTAL_FREQ 8000000

#define BitSet(arg,bit) ((arg) |= (1<<bit))
#define BitClr(arg,bit) ((arg) &= ~(1<<bit)) 
#define BitFlp(arg,bit) ((arg) ^= (1<<bit)) 
#define BitTst(arg,bit) ((arg) & (1<<bit))

//PWM

void InicializaPWM(void)
{
	BitClr(TRISC,2); //PWM1

	T2CON |= 0b00000011; //configura o prescale do timer 2 para 1:16
	BitSet(T2CON,2); //Liga o timer 2
		
	CCP1CON |= 0b00001100;	//configura CCP1 como um PWM
}

void SetaFreqPWM(unsigned int freq)
{
	//PR2 = fosc/(fpwm*4*prescaler)-1;
	PR2 = (8000000/(freq*4*16)) - 1;
	//PR2 = (125000/(freq)) - 1;
}

  void PWM1_Set_Duty(unsigned char d)
  {
      unsigned int temp;
      
      temp=(((unsigned long)(d))*((PR2<<2)|0x03))/255;

      CCPR1L= (0x03FC&temp)>>2;
      CCP1CON=((0x0003&temp)<<4)|0x0F;
  }

//ADC
void adc_init(void){
    ADCON0bits.ADON = 1;
    ADCON0bits.ADCS0 = 1;
    ADCON1bits.PCFG1 = 1;
}

unsigned int adc_read(void){
    ADCON0bits.CHS0 = 0;
    ADCON0bits.CHS1 = 0;
    ADCON0bits.CHS2 = 0;
    
    ADCON0bits.GO = 1;
    while(ADCON0bits.GO == 1);
    return ((((unsigned int)ADRESH)<<2)|(ADRESL>>6));
}

void main(void) {
    BitClr(TRISC, 2);
    TRISE=0x00;
    TRISD = 0x00;
    
    adc_init();
    InicializaPWM();
    lcd_init();

    SetaFreqPWM(5000);
    
    lcd_str("LaurinCorp Inc.");
    char str[50]={0};
    
    while(1){
        lcd_cmd(0xC0);
        unsigned int adc = adc_read();
        unsigned int value = (adc/4);
        sprintf(str, "FREQUENCE : %3d", value);
        lcd_str(str);
        PWM1_Set_Duty(value);
        __delay_ms(50);
    }
    return;
}


