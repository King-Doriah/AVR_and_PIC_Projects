
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdio.h>
#include "lcd.h"

#define _XTAL_FREQ 8000000

void main(void) {
    TRISB = 0x00;
    TRISE = 0x00;
    TRISD = 0x0F;
    TRISC = 0x00;
    
    lcd_init();
    char str[]="Miraldino Doriah";
    lcd_str(str);
    OPTION_REGbits.nRBPU = 1;

    while(1){
        //LEDS PORTD4 e PORTD5 disponiveis
        PORTBbits.RB0 = 0;
        PORTBbits.RB1 = 1;
        PORTBbits.RB2 = 1;
        if(!(PORTDbits.RD0)){ __delay_ms(20); while(!(PORTDbits.RD0)){ lcd_data('1'); } };
        if(!(PORTDbits.RD1)){ __delay_ms(20); while(!(PORTDbits.RD1)){ lcd_data('4'); } };
        if(!(PORTDbits.RD2)){ __delay_ms(20); while(!(PORTDbits.RD2)){ lcd_data('7'); } };
        if(!(PORTDbits.RD3)){ __delay_ms(20); while(!(PORTDbits.RD3)){ lcd_data('*'); } };
        
        PORTBbits.RB0 = 1;
        PORTBbits.RB1 = 0;
        PORTBbits.RB2 = 1;
        if(!(PORTDbits.RD0)){ __delay_ms(20); while(!(PORTDbits.RD0)){ lcd_data('2'); } };
        if(!(PORTDbits.RD1)){ __delay_ms(20); while(!(PORTDbits.RD1)){ lcd_data('5'); } };
        if(!(PORTDbits.RD2)){ __delay_ms(20); while(!(PORTDbits.RD2)){ lcd_data('8'); } };
        if(!(PORTDbits.RD3)){ __delay_ms(20); while(!(PORTDbits.RD3)){ lcd_data('0'); } };

        PORTBbits.RB0 = 1;
        PORTBbits.RB1 = 1;
        PORTBbits.RB2 = 0;
        if(!(PORTDbits.RD0)){ __delay_ms(20); while(!(PORTDbits.RD0)){ lcd_data('3'); } };
        if(!(PORTDbits.RD1)){ __delay_ms(20); while(!(PORTDbits.RD1)){ lcd_data('6'); } };
        if(!(PORTDbits.RD2)){ __delay_ms(20); while(!(PORTDbits.RD2)){ lcd_data('9'); } };
        if(!(PORTDbits.RD3)){ __delay_ms(20); while(!(PORTDbits.RD3)){ lcd_data('#'); } };        
    }
    return;
}
