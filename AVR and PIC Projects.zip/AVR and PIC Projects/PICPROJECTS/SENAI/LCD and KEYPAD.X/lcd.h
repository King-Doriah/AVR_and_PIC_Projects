#include <xc.h>
#define _XTAL_FREQ 8000000

#define PORT PORTD
#define EN   1
#define RS   2

#define BitSet(arg,bit) ((arg) |= (1<<bit))
#define BitClr(arg,bit) ((arg) &= ~(1<<bit)) 
#define BitFlp(arg,bit) ((arg) ^= (1<<bit)) 
#define BitTst(arg,bit) ((arg) & (1<<bit))

void lcd_cmd(unsigned char cmd)
{
    PORT = cmd;
    BitClr(PORTE, RS);
    BitSet(PORTE, EN);
    __delay_ms(2);
    BitClr(PORTE, EN);
    BitClr(PORTE, RS);
    __delay_ms(2);
}

void lcd_data(unsigned char data)
{
    PORT = data;
    BitSet(PORTE, RS);
    BitSet(PORTE, EN);
    __delay_ms(2);
    BitClr(PORTE, EN);
    BitClr(PORTE, RS);
    __delay_ms(2);
}

void lcd_init(void){
    lcd_cmd(0x38);
    __delay_ms(5);
    lcd_cmd(0x38);
    __delay_ms(1);
    lcd_cmd(0x38);
    lcd_cmd(0x08);
    lcd_cmd(0x0C);
    lcd_cmd(0x01);
    lcd_cmd(0x38);
    lcd_cmd(0x80);
    __delay_ms(3);
}

void lcd_str(char str[]){
    unsigned int i = 0;
    while(str[i] != '\0'){
        lcd_data(str[i]);
        i++;
    }
}

void lcd_clear(void){
    lcd_cmd(0x01);
    lcd_cmd(0x80);
}