
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdio.h>
#include "lcd.h"
#define _XTAL_FREQ 8000000

void main(void) {
    TRISD = 0x00;
    TRISB |= (1<<1) | (1<<2);
    
    //RC0 (RELAY1) | RE0 (RELAY2)
    TRISC &= ~(1<<0);
    BitClr(TRISE, 0);
    BitClr(TRISE, 1);
    BitClr(TRISE, 2);
    
    PORTCbits.RC0 = 0;
    PORTEbits.RE0 = 0;
    
    lcd_init();
    lcd_str("LaurinCorp Inc.");
    lcd_cmd(0xC0);
    lcd_str("RELAY CONTROL.");
    
    while(1){
        if(!(PORTBbits.RB1)){
            __delay_ms(100);
            lcd_clear();
            lcd_str("LaurinCorp Inc.");
            lcd_cmd(0xC0);
            lcd_str("RELAY1 : On.");
            PORTCbits.RC0 = 1;
        }else if(!(PORTBbits.RB2)){
            __delay_ms(100);
            lcd_clear();
            lcd_str("LaurinCorp Inc.");
            lcd_cmd(0xC0);
            lcd_str("RELAY2 : On.");
            PORTEbits.RE0 = 1;
        }else if(!(PORTBbits.RB3)){
            __delay_ms(100);
            lcd_clear();
            lcd_str("LaurinCorp Inc.");
            lcd_cmd(0xC0);
            lcd_str("RELAY1 : Off.");
            PORTCbits.RC0 = 0;
        }else if(!(PORTBbits.RB4)){
            __delay_ms(100);
            lcd_clear();
            lcd_str("LaurinCorp Inc.");
            lcd_cmd(0xC0);
            lcd_str("RELAY2 : Off.");
            PORTEbits.RE0 = 0;            
        }
    }
    return;
}
